import React from 'react';
import AppNavbar from "./AppNavBar";
import UserToEditForm from "./UserToEditForm";


export default function UserToEdit(){
         return  <div style = {{height:"100vh", backgroundColor: "rgba(17,15,17,1.0)"}}>
             <UserToEditForm/>
             <AppNavbar/>
         </div>






}